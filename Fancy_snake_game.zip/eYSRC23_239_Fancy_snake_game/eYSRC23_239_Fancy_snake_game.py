'''
*****************************************************************************************
*
*        		===============================================
*           		e-Yantra School Robotics Competition (eYSRC 2023)
*        		===============================================
*
*  This script is to be used to implement Mini Assignment titled- 'Drawing Maurer Rose using Turtle'.
*  
*  This software is made available on an "AS IS WHERE IS BASIS".
*  Licensee/end user indemnifies and will keep e-Yantra indemnified from
*  any and all claim(s) that emanate from the use of the Software or
*  breach of the terms of this agreement.
*  
*  e-Yantra - A MOE project under National Mission on Education using ICT (NMEICT)
*
*****************************************************************************************
'''

# Team ID:          
# 					[ 239 ]
# Author List:      
# 					[Bhargava,Bommidevi]
# Filename:         adventure_game.py
# Functions:        
#                   [ goup,godown,goleft,goright,go_diag_left,go_diag_right,move ]
# Global variables: 
# 					[ x,y ]



####################### IMPORT MODULES #######################
## You are not allowed to make any changes in this section. ##
## You have to implement this assignment with the available ##
## modules for this task.								    ##
##############################################################
import turtle
import time
import random
##############################################################


delay = 0.1
score = 0
level = 1
high_score = 0
obstacles = []
special_obstacles = []

# Creating a window screen
wn = turtle.Screen()
wn.title("Snake Game")
wn.bgpic("war.gif")
wn.setup(width=1000, height=900)
wn.tracer(0)

#adding shapes
turtle.addshape('explode.gif')
turtle.addshape('bomb.gif')
turtle.addshape('egg.gif')
turtle.addshape('body.gif')
turtle.addshape("snake1.gif")
turtle.addshape("snake2.gif")
turtle.addshape("snake3.gif")
turtle.addshape("snake4.gif")
turtle.addshape("snake5.gif")
turtle.addshape("snake6.gif")

# head of the snake
head = turtle.Turtle()
head.color('blue')
head.shape("snake1.gif")
head.speed(5)
head.penup()
head.goto(0, 0)
head.direction = "Stop"

# food in the game
food = turtle.Turtle()
food.speed(0)
food.shape('egg.gif')
food.penup()
food.goto(0, 100)

# creating a title Card
title = turtle.Turtle()
title.penup()
title.color("cyan")
title.goto(-70,400)
title.pendown()
title.write("Snake Adventure", font=("Algerian", 24, "bold"))
title.hideturtle()

#creatting a score Card
pen = turtle.Turtle()
pen.speed(0)
pen.shape("square")
pen.color("White")
pen.penup()
pen.hideturtle()
pen.goto(0, 350)
pen.write("|Level : {}|\t|Score: {}| |High Score : {}| ".format(level,score,high_score), align="center", font=("Algerian", 24, "bold"))
          

# assigning key directions
def goup():
    if head.direction != "down":
        head.direction = "up"
        head.shape("snake1.gif")

def godown():
    if head.direction != "up":
        head.direction = "down"
        head.shape("snake2.gif")

def goleft():
    if head.direction != "right":
        head.direction = "left"
        head.shape("snake3.gif")

def goright():
    if head.direction != "left":
        head.direction = "right"
        head.shape("snake4.gif")
        
def go_diag_left():
    if head.direction in ["up", "left"]:
        head.direction = "diag_up_left"
        head.shape("snake5.gif")
        
    elif head.direction in ["down", "left"]:
        head.direction = "diag_down_left"
        head.shape("snake6.gif")
        
def go_diag_right():
    if head.direction in ["up", "right"]:
        head.direction = "diag_up_right"
        head.shape("snake6.gif")
        
    elif head.direction in ["down", "right"]:
        head.direction = "diag_down_right"
        head.shape("snake5.gif")

#assigning movement
def move():
    global x,y
    if head.direction == "up":
        y = head.ycor()
        head.sety(y + 20)
    if head.direction == "down":
        y = head.ycor()
        head.sety(y - 20)
    if head.direction == "left":
        x = head.xcor()
        head.setx(x - 20)
    if head.direction == "right":
        x = head.xcor()
        head.setx(x + 20)
        
    if head.direction == "diag_up_left":
        x = head.xcor()
        y = head.ycor()
        head.setx(x - 20)
        head.sety(y + 20)

    if head.direction == "diag_up_right":
        x = head.xcor()
        y = head.ycor()
        head.setx(x + 20)
        head.sety(y + 20)

    if head.direction == "diag_down_left":
        x = head.xcor()
        y = head.ycor()
        head.setx(x - 20)
        head.sety(y - 20)

    if head.direction == "diag_down_right":
        x = head.xcor()
        y = head.ycor()
        head.setx(x + 20)
        head.sety(y - 20)

wn.listen()
wn.onkeypress(goup, "w")
wn.onkeypress(godown, "s")
wn.onkeypress(goleft, "a")
wn.onkeypress(goright, "d")
wn.onkeypress(go_diag_left, "q") 
wn.onkeypress(go_diag_right, "e")

segments = []

while True:
    wn.update()
    
    if head.xcor() > 492:
        head.setx(-492)
        
    if head.xcor() < -492:
        head.setx(492)
        
    if head.ycor() > 290:
        head.sety(-310)
        
    if head.ycor() < -310:
        head.sety(290)
        
    if head.distance(food) < 20:
        x = random.randint(-490, 490)
        y = random.randint(-310, 290)
        food.goto(x, y)
        
        # Adding segment
        new_segment = turtle.Turtle()
        new_segment.speed(0)
        new_segment.shape("body.gif")
        new_segment.penup()
        segments.append(new_segment)
        delay -= 0.001
        score += 10
        
        if score > high_score:
            high_score = score
            
        if score % 30 == 0:
            level+=1    
            delay -= 0.001 
            
        pen.clear()
        pen.write("|Level : {}|\t|Score: {}| |High Score : {}| ".format(level,score,high_score), align="center", font=("Algerian", 24, "bold"))
        
            
    # Checking for head collisions with body segments
    for index in range(len(segments) - 1, 0, -1):
        x = segments[index-1].xcor()
        y = segments[index-1].ycor()
        segments[index].goto(x, y)
    if len(segments) > 0:
        x = head.xcor()
        y = head.ycor()
        segments[0].goto(x, y)
        
    move()
    
    for segment in segments:
        if segment.distance(head) < 20:
            time.sleep(1)
            head.goto(0, 0)
            head.direction = "stop"
            colors = random.choice(['red', 'blue', 'green'])
            shapes = random.choice(['square', 'circle'])
            for segment in segments:
                segment.goto(1000, 1000)
            segment.clear()
            score = 0
            delay = 0.1
            pen.clear()
            pen.write("|Level : {}|\t|Score: {}| |High Score : {}| ".format(level,score,high_score), align="center", font=("Algerian", 24, "bold"))
            
       # Create dynamic obstacles 
       
    if random.randint(0, 100) < 5:  # 5% chance to create a new obstacle
        obstacle = turtle.Turtle()
        obstacle.speed(0)
        obstacle.shape('bomb.gif')
        obstacle.penup()
        obstacle.goto(random.randint(-340, 340), random.randint(-310, 290))
        obstacles.append(obstacle)

    # Remove dynamic obstacles
    
    if random.randint(0, 100) < 2:  # 2% chance to remove an existing obstacle
        if obstacles:
            obstacle_to_remove = random.choice(obstacles)
            obstacle_to_remove.goto(1000, 1000)  # move off screen
            obstacles.remove(obstacle_to_remove)

    # Check for collision with obstacles
    
    for obstacle in obstacles:
        if head.distance(obstacle) < 20:
            obstacle.shape('explode.gif')
            # Remove 2 segments 
            for _ in range(2):
                if segments:
                    segment_to_remove = segments.pop()
                    segment_to_remove.goto(1000, 1000)  # move off screen
            
    time.sleep(delay)

wn.mainloop()
