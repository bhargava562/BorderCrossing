import turtle
import time
import random
import os

def create_obstacle(x, y):
    obstacle_up = turtle.Turtle()
    obstacle_up.speed(0)
    obstacle_up.penup()
    obstacle_up.color("darkturquoise")
    obstacle_up.shape("square")
    obstacle_up.shapesize(stretch_wid=20, stretch_len=3, outline=None)
    obstacle_up.goto(x, y)
    obstacle_up.dx = -2
    obstacle_up.dy = 0
    obstacle_up.value = 1

    obstacle_down = turtle.Turtle()
    obstacle_down.speed(0)
    obstacle_down.penup()
    obstacle_down.color("darkturquoise")
    obstacle_down.shape("square")
    obstacle_down.shapesize(stretch_wid=20, stretch_len=3, outline=None)
    obstacle_down.goto(x, -y)
    obstacle_down.dx = -2
    obstacle_down.dy = 0

    return obstacle_up, obstacle_down

def move_obstacle(obstacle_up, obstacle_down, helicopter):
    x = obstacle_up.xcor()
    x += 2 * obstacle_up.dx
    obstacle_up.setx(x)

    x = obstacle_down.xcor()
    x += 2 * obstacle_down.dx
    obstacle_down.setx(x)

    if obstacle_up.xcor() < -650 and helicopter.score <= 20:
        obstacle_up.setx(850)
        obstacle_down.setx(850)
        obstacle_up.value = 1
        block.shapesize(stretch_wid=1, stretch_len=20, outline=None)
        block.goto(500, -150)
        
    if obstacle_up.xcor() < helicopter.xcor() and obstacle_up.value == 1:
        helicopter.score += 1
        obstacle_up.value = 0

def check_collision(helicopter, obstacle_up, obstacle_down):
    if (helicopter.xcor() + 20 > obstacle_up.xcor() - 30) and (helicopter.xcor() - 20 < obstacle_up.xcor() + 30):
        if (helicopter.ycor() + 20 > obstacle_up.ycor() - 180) or (helicopter.ycor() - 20 < obstacle_down.ycor() + 180):
            return True
    return False
    
def game_over(helicopter, wn):
    wn.update()
    helicopter.score = 0
    helicopter.goto(-200, 0)
    helicopter.dy = 0
    name = turtle.textinput("Mission Failed", "Do you want to Retry?:")
    if name in ['Yes', 'yes', 'YES', 'yes', 'OK', 'ok']:
        wn.listen()
        reset_game()     
    else:
        wn.bye()

def go_up(helicopter):
    if helicopter.ycor() < 390: 
        helicopter.dy += 8
        if helicopter.dy > 8:
            helicopter.dy = 8

           
def go_left(player):
    if -700 < player.xcor() < -300:
        player.shape("soldier_pistol2.gif")
        x = player.xcor()
        player.setx(x - 20)

def go_right(player):
    if -700 < player.xcor() < -300:
        player.shape("soldier_pistol.gif")
        x = player.xcor()
        player.setx(x + 20)

def enter_helicopter():
    global in_helicopter
    if in_helicopter == False:
        if player.distance(helicopter) < 50:
            in_helicopter = True
            player.hideturtle()
    else:        
        in_helicopter = False
        player.showturtle()
        

def reset_game():
    global obstacles, player, helicopter, block, game_started, in_helicopter, obstacle_up, obstacle_down
    for obstacle_up, obstacle_down in obstacles:
        obstacle_up.goto(1000, 1000)
        obstacle_down.goto(1000, 1000)
    obstacles = []
    for i in range(7):
        x = 300 + i * 300
        y = 350 - i * 5
        obstacle_up, obstacle_down = create_obstacle(x, y)
        obstacles.append((obstacle_up, obstacle_down))
    helicopter.shape('helicopter.gif')
    player.goto(-620, 50)
    player.dy = 0
    player.score = 0 
    helicopter.goto(-400, 50)
    helicopter.dy = 0
    block.goto(-500, 0)
    block.st()
    game_started = False
    in_helicopter = False
    player.st()

# my screen
wn = turtle.Screen()
wn.title("Level-3: Ice Valley")
wn.bgpic("bg5.gif")
wn.setup(width=1400, height=800)
wn.tracer(0)

# basic shapes
turtle.addshape('helicopter.gif')
turtle.addshape('explode.gif')
turtle.addshape('soldier_pistol.gif')
turtle.addshape('soldier_pistol2.gif')

player = turtle.Turtle()
player.speed(0)
player.penup()
player.shape("soldier_pistol.gif")
player.color("blue")
player.goto(-620, 50)
player.dx = 0
player.dy = 0
player.score = 0

helicopter = turtle.Turtle()
helicopter.speed(0)
helicopter.penup()
helicopter.shape("helicopter.gif")
helicopter.goto(-400, 50)
helicopter.dy = 0

block = turtle.Turtle()
block.speed(1)
block.penup()
block.color("black")
block.shape("square")
block.shapesize(stretch_wid=1, stretch_len=20, outline=None)
block.goto(-500, 0)

flag = turtle.Turtle()
flag.ht()
flag.up()
flag.shape('triangle')
flag.color('red')
flag.speed(0)
flag.setx(680)
    
instruction = turtle.Turtle()
instruction.ht()
instruction.penup()
instruction.speed(0)
instruction.color('Blue')
instruction.goto(-650,270)
instruction.write('MAIN OBJECTIVE: \n Use the Helicopter to cross the Valley \n \n USE Flappy Bird Technique to fly the Helicopter', align="left", font=("Arial", 14, "normal"))
time.sleep(4)
instruction.clear()
instruction.color('red')
instruction.write("HELICOPTER INSTRUCTIONS:\n\nPress [E] to enter the Helicopter \n\n Press [W] to turn ON the engine\n\n Press [SPACEBAR] to fly and Balance the Helicopter", align="left", font=("Arial", 14, "normal"))
time.sleep(5)
instruction.clear()


obstacles = []
for i in range(7):
    x = 300 + i * 300
    y = 350 - i * 5
    obstacle_up, obstacle_down = create_obstacle(x, y)
    obstacles.append((obstacle_up, obstacle_down))

helicopter.score = 0
gravity = -0.3
game_started = False
in_helicopter = False

def start_game():
    global game_started
    if not game_started and in_helicopter:
        wn.listen()
        wn.onkeypress(lambda: go_up(helicopter), "space")
        block.hideturtle()
        game_started = True

wn.listen()
wn.onkeypress(enter_helicopter, "e")
wn.onkeypress(lambda: go_left(player), "a")
wn.onkeypress(lambda: go_right(player), "d")
wn.onkeypress(start_game, "w")

winning = False

while True:
    time.sleep(0.02)
    
    wn.update()
    if game_started:
        helicopter.dy += gravity
        y = helicopter.ycor()
        y += helicopter.dy
        helicopter.sety(y)

        if helicopter.ycor() > 390 or helicopter.ycor() < -390:
            helicopter.shape('explode.gif')
            game_over(helicopter, wn)

        for obstacle_up, obstacle_down in obstacles:
            move_obstacle(obstacle_up, obstacle_down, helicopter)

            if check_collision(helicopter, obstacle_up, obstacle_down):
                helicopter.shape('explode.gif')
                game_over(helicopter, wn)
                

        if helicopter.score > 20 and not winning:
            winning = True
            
        if winning:
            
            if helicopter.xcor()>=500:
                block.st()
                instruction.setx(0)
                instruction.color('black')
                instruction.write("Land the helicopter", align="center", font=("Arial", 14, "normal"))
                
            if helicopter.xcor() < 500:  
                helicopter.setx(helicopter.xcor() + 2)
                
            elif helicopter.ycor() > -100:  
                helicopter.sety(helicopter.ycor() - 1)
                
            else:
                player.goto(helicopter.xcor(),helicopter.ycor()-2)
                flag.st()
                player.setx(helicopter.xcor())
                player.showturtle()
                player.speed(3)
                player.fd(180)
                wn.update()
                time.sleep(2)
                winner = wn.textinput("Mission Passed", "Next Level (yes/no)")
                if winner and winner.lower() == "yes":
                    wn.bye()
                    os.system('Level-4.py')
                else:
                    wn.bye()
        
    else:
        if player.ycor() > block.ycor() + 40:
            player.dy += gravity
            y = player.ycor()
            y += player.dy
            player.sety(y)
                
        if player.ycor() < -390:
            game_over(helicopter, wn)
            
    if game_started == True or player.xcor()==0:
        player.sety(-390)
        if player.ycor() < -390:
            game_over(helicopter, wn)

wn.mainloop()
