import turtle
import time
import random
import os

# initial screen
win = turtle.Screen()
win.title("Level-1: Crash Landing")
win.setup(width=1400, height=800)
win.bgpic('cutscene_1.gif')
win.bgcolor('Black')

# creating Cutscenes in background and changing at every 3 seconds

win.update()
time.sleep(3)
win.bgpic("cutscene_2.gif")

win.update()
time.sleep(3)
win.bgpic("cutscene_3.gif")

win.update()
time.sleep(3)
win.bgpic("cutscene_4.gif")

# adding images
turtle.addshape('gun.gif')
turtle.addshape('soldier_pistol.gif')
turtle.addshape('soldier_pistol2.gif')
turtle.addshape('landmine.gif')
turtle.addshape('landmine_explode.gif')
turtle.addshape('enemy.gif')
turtle.addshape('bunker.gif')
win.update()
time.sleep(2)
win.bgpic("bg3.gif") # setting the background for game
win.tracer(0)

# initial situation
instruction = turtle.Turtle()
instruction.ht()
instruction.speed(0)
instruction.up()
instruction.sety(300)
instruction.write('Present Day in ENEMY BORDER : 16:24',align="center", font=("courier", 17, "normal"))
time.sleep(2)
instruction.clear()

flag = turtle.Turtle() # denotes the direction of the player next objective
flag.up()
flag.speed(0)
flag.ht()
flag.setx(600)
flag.shape('arrow')
flag.color('red')
flag.st()

# initial screen variables
current_screen = 1
second_screen = False
third_screen = False
fourth_screen = False

# just for identify Weapons 
weapons = turtle.Turtle()
weapons.ht()
weapons.up()
weapons.speed(0)
weapons.shape('gun.gif')
weapons.goto(590,350)

# final bunker for story
bunker = turtle.Turtle()
bunker.speed(0)
bunker.shape("bunker.gif")
bunker.penup()
bunker.goto(400,-250)  # Set the initial position of bunker outside the visible area
bunker.hideturtle()

# Create a player
player = turtle.Turtle()
player.speed(0)
player.shape('soldier_pistol.gif')
player.color("blue")
player.penup()
player.goto(-500, -270)

# creating a life text
life_label = turtle.Turtle()
life_label.ht()
life_label.speed(0)
life_label.color("red")
life_label.penup()
life_label.goto(-680, 350)
life_label.write("Lives:", align="left", font=("Arial", 17, "normal"))

# creating a landmine
land_mine = turtle.Turtle()
land_mine.ht()
land_mine.speed(0)
land_mine.shape("landmine.gif")
land_mine.penup()
land_mine.goto(-30, -300)

# creating a life bar in rectangle
life_bar = turtle.Turtle()
life_bar.speed(0)
life_bar.shape("square")
life_bar.shapesize(stretch_wid=1, stretch_len=5)
life_bar.color("green")
life_bar.penup()
life_bar.goto(-570, 360)
life = 4 # setting the 4 instances for life bar

# Create a gun turtle
gun = turtle.Turtle()
gun.speed(0)
gun.shape("gun.gif")
gun.penup()
gun.goto(-200, -150)

# enemy list and executions
enemies = []
for _ in range(6):
    enemy = turtle.Turtle()
    enemy.speed(0)
    enemy.shape('enemy.gif')
    enemy.color('red')
    enemy.penup()
    enemy.goto(random.randint(700, 800), -260)
    enemies.append(enemy)
    
# Create bullets
bullets = []

player_direction = 'right'  # Initial direction of the player

# Create a bullet count display
bullet_display = turtle.Turtle()
bullet_display.hideturtle()
bullet_display.speed(0)
bullet_display.color("black")
bullet_display.penup()
bullet_display.goto(-680, 300)

# Variable to track gun collection
gun_collected = False

# Variable for jumping
is_jumping = False

# Initialize bullet count
bullet_count = 0

# moving left             
def go_left():
    global player_direction
    if player.xcor()>-700:
        player.shape('soldier_pistol2.gif')
        player_direction = 'left'  # Update player_direction to left
        x = player.xcor()
        player.setx(x - 20)

# moving right  
def go_right():
    global player_direction
    player.shape('soldier_pistol.gif')
    player_direction = 'right'  # Update player_direction to right
    x = player.xcor()
    player.setx(x + 20)

# jumping
def jump():
    global is_jumping
    if not is_jumping:
        player.dy = 9   # increasing some y cordinate when this function called by pressing key
        is_jumping = True # creating a jumping variable

# enemy and bullet collision
def check_enemy_hit():
    global life
    for enemy in enemies:
        for bullet in bullets:
            if bullet.distance(enemy) < 20:
                enemy.hideturtle()
                enemy.goto(2000, 2000)  # Move enemy out of sight
                bullets.remove(bullet)
                bullet.hideturtle()
                break

# moving enemies            
def move_enemies():
    global life
    for enemy in enemies:
        enemy.setx(enemy.xcor() - 3)  # Move enemies towards the player on x-axis

        # Check if enemy reaches the player's position
        if enemy.distance(player) < 20:
            enemy.hideturtle()
            enemies.remove(enemy)
            life -= 1
            # Update life bar display based on remaining life
            if life == 3:
                life_bar.color("yellow")
                life_bar.shapesize(stretch_wid=1, stretch_len=3.75)
            elif life == 2:
                life_bar.color("red")
                life_bar.shapesize(stretch_wid=1, stretch_len=2.5)
            elif life == 1:
                life_bar.shapesize(stretch_wid=1, stretch_len=1.25)
            elif life == 0:
                life_bar.hideturtle()
                time.sleep(1)
                retry = win.textinput("Game Over", "Do you want to retry? (yes/no)")
                if retry is not None and retry.lower() == 'yes':
                    reset_game()
                else:
                    win.bye()

# resetting game by resetting variables and turtles                    
def reset_game():
    global player, gun, bullets, bullet_count, gun_collected, life, bullet_display, life_bar, land_mine, bunker, enemies, current_screen

    # Reset current screen to 1 and hide elements from other screens
    current_screen = 1
    win.listen()
    # Reset player position
    player.goto(-500, -270)
    player.shape('soldier_pistol.gif')
    player_direction = 'right'
    player.dy = 0
    is_jumping = False

    # Reset gun and its availability
    gun.showturtle()
    gun.goto(-200, -150)
    gun_collected = False

    # Clear and reset bullets
    for bullet in bullets:
        bullet.hideturtle()
    bullets.clear()
    bullet_count = 0
    bullet_display.clear()
    bullet_display.write(f"Bullets: {bullet_count}", align="left", font=("Arial", 20, "normal"))

    # Reset life and life bar
    life = 4
    life_bar.color("green")
    life_bar.shapesize(stretch_wid=1, stretch_len=5)
    life_bar.st()

    # Reset landmine and bunker status
    land_mine.goto(-30, -300)
    land_mine.hideturtle()
    bunker.goto(400, -250)
    bunker.hideturtle()

    # Hide instruction and other elements
    instruction.clear()
    weapons.clear()
    weapons.goto(590,350)
    
    life_label.clear()
    life_label.write("Lives:", align="left", font=("Arial", 17, "normal"))

    # Hide enemies from other screens
    for enemy in enemies:
        enemy.hideturtle()
    enemies.clear()

    # Re-populate enemies for the starting screen
    for _ in range(6):
        enemy = turtle.Turtle()
        enemy.speed(0)
        enemy.shape('enemy.gif')
        enemy.color('red')
        enemy.penup()
        enemy.goto(random.randint(700, 800), -260)
        enemies.append(enemy)

# shooting logic and bullet movement when pressed space
def shoot():
    global bullet_count, gun_collected, player_direction
    
    # the player cannot shoot if the gun is not picked and all the bullets are finished
    if gun_collected and bullet_count > 0: 
        bullet = turtle.Turtle()
        bullet.speed(0)
        bullet.shape("circle")
        bullet.shapesize(0.3)
        bullet.color("black")
        bullet.penup()

        bullet_y = player.ycor() + 10
        bullet.sety(bullet_y)

        # making the bullet to move left if the player shoots at left side
        if player_direction == 'left':
            bullet.setx(player.xcor() - 20)
            bullet.initial_direction = 'left' # using initial to avoid the bullet from changing direction after fired
            
        # making the bullet to move right if the player shoots at right side    
        else:
            bullet.setx(player.xcor() + 20)
            bullet.initial_direction = 'right'

        # after all these conditions the bullet will fire
        bullet.showturtle()
        bullets.append(bullet)
        bullet_count -= 1
        bullet_display.clear()
        bullet_display.write(f"Bullets: {bullet_count}", align="left", font=("Arial", 20, "normal"))
    
# main movement for bullet, enemy, and some collision detection
def move():
    global gun_collected, is_jumping, bullet_count, life

    if bullet_count == 0:
        bullet_display.clear()
        weapons.ht()
        weapons.clear()

    for bullet in bullets:
        x = bullet.xcor()
        bullet.setx(x + 20 if bullet.initial_direction == 'right' else x - 20)  # Adjust bullet speed and direction here

        # Check collision between bullet and player
        if bullet.distance(player) < 20:
            bullet.hideturtle()
            bullets.remove(bullet)
            life -= 1
            # Update life bar display based on remaining life
            if life == 3:
                life_bar.color("yellow")
                life_bar.shapesize(stretch_wid=1, stretch_len=3.75)
            elif life == 2:
                life_bar.color("red")
                life_bar.shapesize(stretch_wid=1, stretch_len=2.5)
            elif life == 1:
                life_bar.shapesize(stretch_wid=1, stretch_len=1.25)
            elif life == 0:
                life_bar.hideturtle()
                time.sleep(1)
                retry = win.textinput("Game Over", "Do you want to retry? (yes/no)")
                if retry is not None and retry.lower() == 'yes':
                    reset_game()
                else:
                    win.bye()
                    
    player_x, player_y = player.position()
    landmine_x, landmine_y = land_mine.position()

    collision_distance = 32  # Change the collision detection distance as needed

    # Check if landmine is visible and player's position intersects with landmine's position
    if land_mine.isvisible() and \
            (landmine_x - collision_distance < player_x < landmine_x + collision_distance) and \
            (landmine_y - collision_distance < player_y < landmine_y + collision_distance):
        # Hide landmine and life bar
        land_mine.hideturtle()
        life_bar.hideturtle()
        player.shape('landmine_explode.gif')
        
        # Creating an exploding effect by stamping an image on the screen
        
        player.hideturtle()  # Hide the player turtle
        player_stamp = player.stamp()  # Stamping the player shape onto the screen
        win.update()  # Update the window to show the stamp

        # Wait for a moment before displaying text input
        time.sleep(1)

        # Display text input
        retry = win.textinput("Game Over!", "Do you want to retry? (yes/no)")
        if retry is not None and retry.lower() == 'yes':
            reset_game()
        else:
            win.bye()
            return  # Returning to exit the function after displaying the text input

        # Cleaning up by removing the stamped image
        player.clearstamp(player_stamp)
        player.showturtle()
                
    # Check collision between player and gun
    if not gun_collected and player.distance(gun) < 20:
        gun.hideturtle()
        weapons.write("Picked up:", align="left", font=("Arial", 17, "normal"))
        weapons.goto(660,330)
        weapons.st()
        bullet_count = 50  # Set bullet count after collecting the gun
        bullet_display.write(f"Bullets: {bullet_count}", align="left", font=("Arial", 20, "normal"))
        gun_collected = True

    # Simulate jumping
    if is_jumping:
        player.dy -= 0.3  # Adjusting gravity
        y = player.ycor()
        y += player.dy
        player.sety(y)

        if y <= -270:  # Ground level
            player.sety(-270)  # Setting the player at the ground level
            is_jumping = False  # Resetting jumping status
            player.dy = 0  # Resetting vertical speed

# changing the screens 
def move_map():
    global current_screen, enemies

    # making current enemies and current obstacles to display at the current screen
    if player.xcor() >= 700 and current_screen == 1:
        current_screen = 2
        gun.ht()
        player.setx(-700)
        for enemy in enemies:
            enemy.hideturtle()
        enemies.clear()
        for _ in range(6):
            enemy = turtle.Turtle()
            enemy.speed(0)
            enemy.shape('enemy.gif')
            enemy.color('red')
            enemy.penup()
            enemy.goto(random.randint(400, 600), random.randint(-270, -200))
            enemies.append(enemy)    
        
    elif player.xcor() >= 700 and current_screen == 2:
        current_screen = 3
        player.setx(-700)
        land_mine.st()
        for enemy in enemies:
            enemy.hideturtle()
        enemies.clear()

        # Display enemies again
        for _ in range(8):
            enemy = turtle.Turtle()
            enemy.speed(0)
            enemy.shape('enemy.gif')
            enemy.color('red')
            enemy.penup()
            enemy.goto(random.randint(400, 600), random.randint(-270, -200))
            enemies.append(enemy)

    elif player.xcor() >= 700 and current_screen == 3:
        current_screen = 4
        player.setx(-700)
        land_mine.ht()
        bunker.st()
        
        for enemy in enemies:
            enemy.hideturtle()
        enemies.clear()
        
        # Display enemies again
        for _ in range(7):
            enemy = turtle.Turtle()
            enemy.speed(0)
            enemy.shape('enemy.gif')
            enemy.color('red')
            enemy.penup()
            enemy.goto(random.randint(400, 600), random.randint(-270, -200))
            enemies.append(enemy)
        
        
win.listen()
win.onkeypress(go_left, "a")
win.onkeypress(go_right, "d")
win.onkey(jump, "w")
win.onkey(shoot, "space")

# Main game loop
while True:
    move_map()  # Move the map
    move()
    check_enemy_hit()
    move_enemies()
    if player.distance(bunker)<=60 and current_screen == 4:
        time.sleep(1)
        player.ht()
        bunker.ht()
        life_bar.ht()
        life_label.clear()
        bullet_display.ht()
        weapons.ht()
        instruction.clear()
        win.update()
        time.sleep(3)
        win.bgpic("cutscene_5.gif")
        win.update()
        time.sleep(3)
        win.bgpic("cutscene_6.gif")
        win.update()
        time.sleep(2)
        win.bye()
        os.system('Level-2.py')
        
    win.update()  # Update the screen
    time.sleep(0.02)
win.tracer(1)
turtle.done()
