import turtle
import time
import random

win = turtle.Screen()
win.title("level-6: FireWorks")
win.setup(1400, 800)
win.bgpic("clouds.gif")
win.tracer(1)

turtle.addshape('jet.gif')
turtle.addshape('cloud1.gif')
turtle.addshape('cloud2.gif')
turtle.addshape('cloud3.gif')
turtle.addshape('explode.gif')
turtle.addshape('normal_missile.gif')
turtle.addshape('vertical_missile.gif')

cloudshape = ['cloud1.gif', 'cloud2.gif', 'cloud3.gif']

player = turtle.Turtle()
player.speed(0)
player.shape("jet.gif")
player.penup()
player.goto(0, 0)

cloud = turtle.Turtle()
cloud.ht()
cloud.speed(0)
cloud.penup()

normal_missile = turtle.Turtle()
normal_missile.ht()
normal_missile.up()
normal_missile.speed(0)
normal_missile.shape('normal_missile.gif')

vertical_missile = turtle.Turtle()
vertical_missile.ht()
vertical_missile.up()
vertical_missile.speed(0)
vertical_missile.shape('vertical_missile.gif')



def go_up():
    y = player.ycor()
    player.sety(y + 20)
    check_player_border()

def go_down():
    y = player.ycor()
    player.sety(y - 20)
    check_player_border()

def go_left():
    x = player.xcor()
    player.setx(x - 20)
    check_player_border()

def go_right():
    x = player.xcor()
    player.setx(x + 20)
    check_player_border()

    
def check_player_border():
    x, y = player.xcor(), player.ycor()
    if x > 700:
        player.setx(-700)
    elif x < -700:
        player.setx(700)
    if y > 400:
        player.sety(-400)
    elif y < -400:
        player.sety(400)
        
def normal_missile_attack():
    if time.time() - start_time < 20: 
        normal_missile.speed(0)
        y = random.randint(-400, 400)
        normal_missile.goto(800, y)
        normal_missile.st()
        normal_missile.speed(7)
        while normal_missile.xcor() > -800:
            normal_missile.setx(normal_missile.xcor() - 50)
            if player.distance(normal_missile) < 50:
                player.shape('explode.gif')
                normal_missile.ht()
                return True
        normal_missile.ht()
        return False

def vertical_missile_attack():
    if time.time() - start_time < 20:
        vertical_missile.speed(0)
        vertical_missile.goto(random.randint(-700, 700), -400)
        vertical_missile.st()
        vertical_missile.speed(7)
        while vertical_missile.ycor() < 400:
            vertical_missile.sety(vertical_missile.ycor() + 50)
            if player.distance(vertical_missile) < 100:
                player.shape('explode.gif')
                vertical_missile.ht()
                return True
        vertical_missile.ht()
        return False
  
    
def clouds():
    cloud.speed(0)
    cloud.shape(random.choice(cloudshape))
    z = random.randint(-400, 400)
    cloud.goto(850, z)
    cloud.st()
    cloud.speed(5)
    cloud.goto(-850, z)

win.listen()
win.onkeypress(go_up, "w")
win.onkeypress(go_down, "s")
win.onkeypress(go_left, "a")
win.onkeypress(go_right, "d")

start_time = time.time()
vertical_missile_time = time.time()

while True:
    clouds()

    if normal_missile_attack():
        response = turtle.textinput("Game Over", "You lost! Do you want to restart? (yes/no)")
        if response.lower() == "yes":
            win.listen()
            start_time = time.time()
            vertical_missile_time = time.time()
            player.goto(0, 0) 
            player.shape('jet.gif')
        else:
            win.bye()
            break
        
    if time.time() - vertical_missile_time > 3:
        if vertical_missile_attack():
            response = turtle.textinput("Game Over", "You lost! Do you want to restart? (yes/no)")
            if response.lower() == "yes":
                win.listen()
                start_time = time.time()
                vertical_missile_time = time.time()
                player.goto(0, 0) 
                player.shape('jet.gif')
            else:
                win.bye()
                break

        if abs(vertical_missile.xcor()) > 800 or abs(vertical_missile.ycor()) > 400:
            vertical_missile.hideturtle()

        
    if time.time() - start_time > 20:
        vertical_missile.hideturtle()
        normal_missile.hideturtle()
        
        if player.xcor() < 500:  
            player.setx(player.xcor() + 360)
        else:  
            win.update()
            response = turtle.textinput("Misson Passed", "You won! Border Crossed")
            player.shape("jet.gif")
            if response.lower() == "yes":
                win.bye()
            break
    win.update()    
    time.sleep(0.001)   
win.mainloop()
