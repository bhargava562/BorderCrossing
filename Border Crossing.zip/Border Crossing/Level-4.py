import turtle
import time
import math
import random
import os

win = turtle.Screen()
win.title("Level-5: Surgical strike")
win.setup(width=1400, height=800)
turtle.addshape('gun.gif')
turtle.addshape('soldier_pistol.gif')
turtle.addshape('soldier_pistol2.gif')
turtle.addshape('landmine.gif')
turtle.addshape('landmine_explode.gif')
turtle.addshape('AAcannonperson.gif')
turtle.addshape('AAcannonperson2.gif')
turtle.addshape('AAcannon.gif')
turtle.addshape('jet.gif')
turtle.addshape('enemy.gif')
turtle.addshape('e-heli.gif')
win.bgpic("bg2.gif")
win.tracer(0)

instruction = turtle.Turtle()
instruction.ht()
instruction.speed(0)
instruction.up()
instruction.sety(300)
instruction.write('Eliminate the robo guards',align="center", font=("courier", 17, "normal"))
time.sleep(2)
instruction.clear()

enemies = []
for _ in range(10):
    enemy = turtle.Turtle()
    enemy.speed(0)
    enemy.shape('enemy.gif')
    enemy.color('red')
    enemy.penup()
    enemy.goto(random.randint(700, 800), -260)
    enemies.append(enemy)
    
# just for identify Weapons
weapons = turtle.Turtle()
weapons.ht()
weapons.up()
weapons.speed(0)
weapons.shape('gun.gif')
weapons.goto(590,350)

in_flak =False
in_jet =False
gun_collected = False
is_jumping = False

current_screen = 1
second_screen = False
third_screen = False
fourth_screen = False


flak = turtle.Turtle()
flak.up()
flak.ht()
flak.speed()
flak.goto(0,-270)
flak.shape('AAcannon.gif')


flag = turtle.Turtle()
flag.up()
flag.speed(0)
flag.ht()
flag.setx(600)
flag.shape('arrow')
flag.color('red')
flag.st()

jet = turtle.Turtle()
jet.up()
jet.ht()
jet.speed()
jet.goto(-400,-270)
jet.shape('jet.gif')

# Create a player
player = turtle.Turtle()
player.speed(0)
player.shape('soldier_pistol.gif')
player.color("blue")
player.penup()
player.goto(-300, -270)

life_label = turtle.Turtle()
life_label.ht()
life_label.speed(0)
life_label.color("red")
life_label.penup()
life_label.goto(-680, 350)
life_label.write("Lives:", align="left", font=("Arial", 17, "normal"))

land_mine = turtle.Turtle()
land_mine.ht()
land_mine.speed(0)
land_mine.shape("landmine.gif")
land_mine.penup()
land_mine.goto(-30, -300)
land_mine.st()

life_bar = turtle.Turtle()
life_bar.speed(0)
life_bar.shape("square")
life_bar.shapesize(stretch_wid=1, stretch_len=5)
life_bar.color("green")
life_bar.penup()
life_bar.goto(-570, 360)
life = 4

# Create a gun turtle
gun = turtle.Turtle()
gun.speed(0)
gun.shape("gun.gif")
gun.penup()
gun.goto(-200, -260)

# Create bullets
bullets = []

player_direction = 'right'  # Initial direction of the player

# Create a bullet count display
bullet_display = turtle.Turtle()
bullet_display.hideturtle()
bullet_display.speed(0)
bullet_display.color("black")
bullet_display.penup()
bullet_display.goto(-680, 300)

def check_enemy_hit():
    global life

    for enemy in enemies:
        for bullet in bullets:
            if bullet.distance(enemy) < 20:
                enemy.hideturtle()
                enemy.goto(2000, 2000)  # Move enemy out of sight
                bullets.remove(bullet)
                bullet.hideturtle()
                break

            
def move_enemies():
    global life
    for enemy in enemies:
        enemy.setx(enemy.xcor() - 2)  # Move enemies towards the player on x-axis

        # Check if enemy reaches the player's position
        if enemy.distance(player) < 20:
            enemy.hideturtle()
            enemies.remove(enemy)
            life -= 1
            # Update life bar display based on remaining life
            if life == 3:
                life_bar.color("yellow")
                life_bar.shapesize(stretch_wid=1, stretch_len=3.75)
            elif life == 2:
                life_bar.color("red")
                life_bar.shapesize(stretch_wid=1, stretch_len=2.5)
            elif life == 1:
                life_bar.shapesize(stretch_wid=1, stretch_len=1.25)
            elif life == 0:
                life_bar.hideturtle()
                time.sleep(1)
                retry = win.textinput("Game Over", "Do you want to retry? (yes/no)")
                if retry is not None and retry.lower() == 'yes':
                    reset_game()
                else:
                    win.bye()
                    
# Initialize bullet count
bullet_count = 0

def distance(t1, t2):
    # Calculate the distance between two turtles
    return ((t1.xcor() - t2.xcor()) ** 2 + (t1.ycor() - t2.ycor()) ** 2) ** 0.5

def enter_exit_vehicle():
    global in_flak, in_jet

    flak_distance = distance(player, flak)
    jet_distance = distance(player, jet)

    if flak_distance < 50 and not in_jet:
        if not in_flak:
            flak.shape('AAcannonperson.gif')
            player.ht()
            in_flak = True
        else:
            flak.shape('AAcannon.gif')
            player.st()
            in_flak = False

    if jet_distance < 50 and not in_flak:
        if not in_jet:
            player.ht()
            in_jet = True
        else:
            player.st()
            in_jet = False

                
def go_left():
    global player_direction, in_tank, in_flak
    # to avoid player to move to left end
    if player.xcor()>-700:
        if in_flak:
            flak.shape('AAcannonperson2.gif')
            flak.direction = 'left'

        else:
            # Normal player movement for other cases
            player.shape('soldier_pistol2.gif')
            player_direction = 'left'
            x = player.xcor()
            player.setx(x - 20)

def go_right():
    global player_direction, in_flak, in_jet
    if in_flak:
        flak.shape('AAcannonperson.gif')
        flak.direction = 'right'

    elif in_jet:
        x = jet.xcor()
        jet.setx(x + 20)
        if jet.xcor() >= 0:
            jet.sety(300)
            jet.goto(600, 300)
            win.update()
            winner()
    else:
        # Normal player movement for other cases
        player.shape('soldier_pistol.gif')
        player_direction = 'right'
        x = player.xcor()
        player.setx(x + 20)

def winner(): # creating the winner and move to next level
    winner_response = win.textinput('Mission Passed', 'Next Level? (Yes/No)')
    if winner_response is not None and winner_response.lower() == 'yes':
        win.bye()
        os.system('Level-5.py')
    else:
        win.bye()
        
def jump():
    global is_jumping
    if not is_jumping:
        player.dy = 9
        is_jumping = True
        
def reset_game():
    global player, gun, bullets, bullet_count, gun_collected, life, bullet_display, life_bar
    global in_flak, in_jet, is_jumping, current_screen, second_screen, third_screen, fourth_screen

    #reset the player shape
    player.shape('soldier_pistol.gif')
    
    # Clear ongoing instructions
    instruction.clear()
    win.listen()
    # Reset screen background to starting one
    win.bgpic("bg2.gif")
    weapons.goto(590,350)
    
    # Reset current screen variables
    current_screen = 1
    second_screen = False
    third_screen = False
    fourth_screen = False

    # Reset player position
    player.goto(-300, -270)
    player.showturtle()
    player.dy = 0
    is_jumping = False

    # Show the gun and set its initial position
    gun.showturtle()
    gun.goto(-200, -260)

    # Clear bullets and reset bullet count
    for bullet in bullets:
        bullet.hideturtle()
    bullets.clear()
    bullet_count = 0

    # Hide the bullet count and gun collection label
    bullet_display.clear()
    weapons.clear()
    gun_collected = False

    # Reset life and display the life bar
    life = 4
    life_bar.shapesize(stretch_wid=1, stretch_len=5)
    life_bar.color("green")
    life_bar.showturtle()

    # Reset vehicles and their statuses
    in_flak = False
    flak.hideturtle()
    in_jet = False
    jet.hideturtle()

    # Reset enemies and their positions
    for enemy in enemies:
        enemy.hideturtle()
    enemies.clear()

    # Re-initialize enemies for the first screen
    for _ in range(10):
        enemy = turtle.Turtle()
        enemy.speed(0)
        enemy.shape('enemy.gif')
        enemy.color('red')
        enemy.penup()
        enemy.goto(random.randint(700, 800), -260)
        enemies.append(enemy)

    # Reset landmine and its status
    land_mine.goto(-30, -300)
    land_mine.showturtle()

    # Reset flag position
    flag.setx(600)
    flag.showturtle()

    # Reset life label
    life_label.clear()
    life_label.goto(-680, 350)
    life_label.write("Lives:", align="left", font=("Arial", 17, "normal"))

    # Clear any remaining instructions
    instruction.clear()

# Define lists to track bullets for flak gun.. i.e Anti aircraft gun
flak_bullets = []

def shoot():
    global flak_bullets, bullet_count

    if in_flak:
        bullet = turtle.Turtle()
        bullet.speed(0)
        bullet.shape("circle")
        bullet.shapesize(0.5)
        bullet.color("red")
        bullet.penup()

        bullet.setposition(player.xcor(), player.ycor() + 20)
        bullet.dy = 4    # Bullet goes upwards
        bullet.dx = 3    # Initial bullet direction is right

        bullet.showturtle()
        flak_bullets.append(bullet)

        # For left direction shooting
        if flak.direction == 'left':
            bullet.dx *= -1  # Reverse the bullet's x-direction

    else:
        # Normal shooting logic for the player
        if gun_collected and bullet_count > 0:
            bullet = turtle.Turtle()
            bullet.speed(0)
            bullet.shape("circle")
            bullet.shapesize(0.3)
            bullet.color("black")
            bullet.penup()

            bullet_y = player.ycor() + 10
            bullet.sety(bullet_y)

            if player_direction == 'left':
                bullet.setx(player.xcor() - 20)
                bullet.initial_direction = 'left'
            else:
                bullet.setx(player.xcor() + 20)
                bullet.initial_direction = 'right'

            bullet.showturtle()
            bullets.append(bullet)
            bullet_count -= 1
            bullet_display.clear()
            bullet_display.write(f"Bullets: {bullet_count}", align="left", font=("Arial", 20, "normal"))

    for bullet in flak_bullets:
        bullet.setx(bullet.xcor() + bullet.dx)
        bullet.sety(bullet.ycor() + bullet.dy)

        # Check collision between flak bullets and enemies
        for enemy in enemies:
            if bullet.distance(enemy) < 20:
                enemy.hideturtle()
                enemy.goto(2000, 2000)  # Move enemy out of sight
                bullet.hideturtle()
                flak_bullets.remove(bullet)
                break  # Break after hiding the enemy once

# Inside the move function
def move():
    global gun_collected, is_jumping, bullet_count,life
    if bullet_count == 0:
        bullet_display.clear()
        weapons.ht()
        weapons.clear()
        

    # Move bullets for flak
    for bullet in flak_bullets:
        bullet.setx(bullet.xcor() + bullet.dx)
        bullet.sety(bullet.ycor() + bullet.dy)

    for bullet in flak_bullets[:]:  # Iteration through a copy of the list to avoid modification during iteration
        bullet.setx(bullet.xcor() + bullet.dx)
        bullet.sety(bullet.ycor() + bullet.dy)

        # Check collision between flak bullets and enemies
        for enemy in enemies[:]:  # Iterate through a copy of the list to avoid modification during iteration
            if bullet.distance(enemy) < 20:
                enemy.hideturtle()
                enemy.goto(2000, 2000)  # Move enemy out of sight
                bullet.hideturtle()
                flak_bullets.remove(bullet)
                enemies.remove(enemy)
                break  # Break after hiding the enemy once

    for bullet in bullets:
        x = bullet.xcor()
        bullet.setx(x + 20 if bullet.initial_direction == 'right' else x - 20)  # Adjust bullet speed and direction here

        # Check collision between bullet and player
        if bullet.distance(player) < 20:
            bullet.hideturtle()
            bullets.remove(bullet)
            life -= 1
            # Update life bar display based on remaining life
            if life == 3:
                life_bar.color("yellow")
                life_bar.shapesize(stretch_wid=1, stretch_len=3.75)
            elif life == 2:
                life_bar.color("red")
                life_bar.shapesize(stretch_wid=1, stretch_len=2.5)
            elif life == 1:
                life_bar.shapesize(stretch_wid=1, stretch_len=1.25)
            elif life == 0:
                life_bar.hideturtle()
                time.sleep(1)
                retry = win.textinput("Game Over", "Do you want to retry? (yes/no)")
                if retry is not None and retry.lower() == 'yes':
                    reset_game()
                else:
                    win.bye()

    player_x, player_y = player.position()
    landmine_x, landmine_y = land_mine.position()

    collision_distance = 32  # Change the collision detection distance as needed

    # Check if landmine is visible and player's position intersects with landmine's position
    if land_mine.isvisible() and \
            (landmine_x - collision_distance < player_x < landmine_x + collision_distance) and \
            (landmine_y - collision_distance < player_y < landmine_y + collision_distance):
        # Hide landmine and life bar
        land_mine.hideturtle()
        life_bar.hideturtle()
        player.shape('landmine_explode.gif')
        
        # Creating an exploding effect by stamping an image on the screen
        
        player.hideturtle()  # Hide the player turtle
        player_stamp = player.stamp()  # Stamping the player shape onto the screen
        win.update()  # Update the window to show the stamp

        # Wait for a moment before displaying text input
        time.sleep(1)

        # Display text input
        retry = win.textinput("Game Over!", "Do you want to retry? (yes/no)")
        if retry is not None and retry.lower() == 'yes':
            reset_game()
        else:
            win.bye()
            return  # Returning to exit the function after displaying the text input

        # Cleaning up by removing the stamped image
        player.clearstamp(player_stamp)
        player.showturtle()
                
    # Check collision between player and gun
    if not gun_collected and player.distance(gun) < 20:
        gun.hideturtle()
        weapons.write("Picked up:", align="left", font=("Arial", 17, "normal"))
        weapons.goto(660,330)
        weapons.st()
        bullet_count = 100  # Set bullet count after collecting the gun
        bullet_display.write(f"Bullets: {bullet_count}", align="left", font=("Arial", 20, "normal"))
        gun_collected = True

    # Simulate jumping
    if is_jumping:
        player.dy -= 0.3  # Adjust gravity
        y = player.ycor()
        y += player.dy
        player.sety(y)

        if y <= -270:  # Ground level
            player.sety(-270)  # Set the player at the ground level
            is_jumping = False  # Reset jumping status
            player.dy = 0  # Reset vertical speed
def move_map():
    global current_screen, second_screen, third_screen, fourth_screen

    if player.xcor() >= 700 and current_screen == 1:
        # Transition to the second screen
        second_screen = True
        current_screen = 2
        player.setx(-700)
        land_mine.ht()
        flak.showturtle()
        instruction.write('Eliminate the flyers using AA gun',align="center", font=("courier", 17, "normal"))
        time.sleep(2)
        instruction.clear()

        for enemy in enemies:
            enemy.hideturtle()
        enemies.clear()
        
        # Display enemies again
        for _ in range(7):
            enemy = turtle.Turtle()
            enemy.speed(0)
            enemy.shape('e-heli.gif')
            enemy.color('red')
            enemy.penup()
            enemy.goto(random.randint(400, 600), random.randint(300, 370))
            enemies.append(enemy)
            

    if player.xcor() >= 700 and second_screen and current_screen == 2:
        # Transition to the third screen
        third_screen = True
        current_screen = 3
        player.setx(-700)
        flak.hideturtle()
        land_mine.showturtle()
        instruction.write('pass through for protection',align="center", font=("courier", 17, "normal"))
        time.sleep(2)
        instruction.clear()

        for enemy in enemies:
            enemy.hideturtle()
        enemies.clear()
        
        # Display enemies again
        for _ in range(40):
            enemy = turtle.Turtle()
            enemy.speed(0)
            enemy.shape('enemy.gif')
            enemy.color('red')
            enemy.penup()
            enemy.goto(random.randint(400, 600), random.randint(-270, -200))
            enemies.append(enemy)

    if player.xcor() >= 700 and third_screen and current_screen == 3:
        # Transition to the fourth screen
        fourth_screen = True
        current_screen = 4
        land_mine.hideturtle()
        player.setx(-700)
        win.update()
        win.bgpic('airbase.gif')
        for enemy in enemies:
            enemy.hideturtle()
        enemies.clear()
        player.setx(-700)
        jet.goto(-400,-250)
        jet.showturtle()

win.listen()
win.onkeypress(go_left, "a")
win.onkeypress(go_right, "d")
win.onkey(jump, "w")
win.onkey(enter_exit_vehicle, "e")
win.onkey(shoot, "space")

# Main game loop
while True:
    move_map()          # function Calling
    move()
    check_enemy_hit()
    move_enemies()    
    win.update()  
    time.sleep(0.02)
win.tracer(1)
turtle.done()
