 Welcome to border crossing. i have made this game into 5 levels please enjoy that

open the bordercrossing file to start game

main story help the soldier vijay to escape from the enemy border. the enemies are using robots as soldier. the player can acquire only pistol for realistic logic. and also the keys are

W to forward/jump
S to backward
A to left
D to right
space to Shoot/fly helicopter
e to enter vehicles (player must be near to the vechicle)
w to start the engine of helicopter 

press D to move the jet

please note some of the keys are not working on live recording but it must actually work on normal gameplay so have fun.
 