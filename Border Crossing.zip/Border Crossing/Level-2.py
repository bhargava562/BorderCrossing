import turtle
import random
import time
import os

# Initialize the screen
win = turtle.Screen()
win.title("Level-2: Long and Dangerous ROAD")
win.setup(1400, 800)
win.bgcolor('black')
win.bgpic("cutscene_7.gif")
win.update()
time.sleep(3)
win.bgpic("cutscene_8.gif")
win.update()
time.sleep(3)
win.bgpic("bg 25.gif")
win.tracer(0)

# Register shapes
win.register_shape("jeep.gif")
win.register_shape("e-jeep.gif")
win.register_shape("helitop.gif")
win.register_shape("explode.gif")
win.register_shape("player2.gif")

# Create player turtle
player = turtle.Turtle()
player.shape("player2.gif")
player.penup()
player.speed(0)
player.goto(-500, -300)

# Create car turtle
car = turtle.Turtle()
car.shape("jeep.gif")
car.shapesize(2, 2)
car.up()
car.goto(-370, -300)

bullets = []  # List to manage bullets
last_bullet_fire_time = time.time()

# Create a helicopter turtle
helicopter = turtle.Turtle()
helicopter.shape("helitop.gif")
helicopter.shapesize(2, 2)
helicopter.up()
helicopter.goto(0, -420)
helicopter.hideturtle()

bullet_speed = 5  # Speed of the bullet
bullet_firing_delay = 1.5

# Function to fire a bullet towards the player's car coordinates
def fire_bullet():
    bullet = turtle.Turtle()
    bullet.shape("circle")
    bullet.shapesize(0.5, 0.5)
    bullet.color("yellow")
    bullet.up()
    bullet.goto(helicopter.xcor(), helicopter.ycor())
    bullet.hideturtle()
    target_x, target_y = car.xcor(), car.ycor()
    bullet.setheading(bullet.towards(target_x, target_y))
    bullets.append(bullet)

# Function to check collision between bullet and player
def check_bullet_collision():
    if bullet.distance(player) < 20:
        car.shape('explode.gif')
        return True
    return False

# Function to reset bullet position
def reset_bullet():
    bullet.hideturtle()
    bullet.goto(-500, -300)

# Initialize enemies
amount_enemies = 7
game_speed = 3
enemy_list = []

for i in range(8):
    enemy = turtle.Turtle()
    enemy.shape("e-jeep.gif")
    enemy.shapesize(2, 2)
    enemy.up()
    speed = random.randint(2, 8)
    enemy.goto(random.randint(-400, 400), 550)
    enemy_list.append((enemy, speed))

# Function to create vertical lines
def create_vertical_line(x_pos):
    vertical_line = turtle.Turtle()
    vertical_line.shape("square")
    vertical_line.color("white")
    vertical_line.shapesize(stretch_wid=50, stretch_len=0.2)
    vertical_line.penup()
    vertical_line.goto(x_pos, 0)
    return vertical_line

vertical_line_left = create_vertical_line(-400)
vertical_line_right = create_vertical_line(400)

# Create road lines
road_lines = []

for i in range(-300, 300, 120):
    road_line = turtle.Turtle()
    road_line.shape("square")
    road_line.color("white")
    road_line.shapesize(stretch_wid=3, stretch_len=0.3)
    road_line.penup()
    road_line.goto(0, i)
    road_lines.append(road_line)

winner_declared = False
game_over = False
player_in_car = False

instruction = turtle.Turtle()
instruction.ht()
instruction.up()
instruction.speed(0)
instruction.color('red')
instruction.goto(0,300)
instruction.write('press [e] to enter the car \n objective: escape to jason safe house', align = 'left', font=("Arial", 15, "normal"))
time.sleep(2)
instruction.clear()

# Define functions for player movements
def enter_car():
    global player_in_car
    if player.distance(car) < 50:
        player_in_car = True
        player.hideturtle()
        move_player_car()
        helicopter.showturtle()
        helicopter.sety(-300)

def move_left():
    if player_in_car:
        if -400 < car.xcor() - 50 < 400:
            car.goto(car.xcor() - 50, car.ycor())
    else:
        x = player.xcor()
        player.setx(x - 20)

def move_right():
    if player_in_car:
        if -400 < car.xcor() + 50 < 400:
            car.goto(car.xcor() + 50, car.ycor())
    else:
        x = player.xcor()
        player.setx(x + 20)

def move_player_car():
    target_pos = (0, 0)
    car_speed = 10
    steps = 10
    diff_x = (target_pos[0] - car.xcor()) / steps
    diff_y = (target_pos[1] - car.ycor()) / steps

    for _ in range(steps):
        car.setx(car.xcor() + diff_x)
        car.sety(car.ycor() + diff_y)
        time.sleep(0.05)
        win.update()

def is_collision(t1, t2):
    distance = t1.distance(t2)
    if distance < 20:
        return True
    else:
        return False

def move_enemy():
    global game_over, winner_declared
    if not game_over and not winner_declared:
        for enemy, speed in enemy_list:
            enemy.sety(enemy.ycor() - speed * game_speed)

            if enemy.ycor() < -400:
                enemy.goto(random.randint(-400, 400), 500)
                speed = random.randint(2, 8)

            if enemy.ycor() > 500:
                enemy.sety(500)

    elif winner_declared:
        for enemy, speed in enemy_list:
            if enemy.ycor() > -400:
                enemy.sety(enemy.ycor() - speed * game_speed*2)

def move_road_lines():
    for road_line in road_lines:
        road_line.sety(road_line.ycor() - 3 * game_speed)

        if road_line.ycor() < -300:
            road_line.sety(360)

def reset_game():
    global game_over, player_in_car, winner_declared, start_time,last_bullet_fire_time
    last_bullet_fire_time = time.time()
    bullet_firing_delay = 1.5
    start_time = time.time()
    win.listen()
    player.st()
    car.shape("jeep.gif")
    
    for enemy, _ in enemy_list:
        enemy.hideturtle()
    enemy_list.clear()

    for bullet in bullets:
        bullet.hideturtle()
    bullets.clear()

    helicopter.hideturtle()
    helicopter.goto(0, -450)

    player.goto(-500, -300)
    car.goto(-370, -300)

    for i in range(8):
        enemy = turtle.Turtle()
        enemy.shape("e-jeep.gif")
        enemy.shapesize(2, 2)
        enemy.up()
        speed = random.randint(2, 8)
        enemy.goto(random.randint(-400, 400), 550)
        enemy_list.append((enemy, speed))

    game_over = False
    player_in_car = False
    winner_declared = False

def game_loop():
    global game_over, winner_declared, start_time, last_bullet_fire_time

    time.sleep(0.01)

    if not game_over:
        if player_in_car:
            move_enemy()
            move_road_lines()
            
            for i in enemy_list:
                if i[0].distance(car) <= 45:
                    game_over = True
                    break

            if time.time() - start_time >= 10 and not winner_declared: 
                helicopter.sety(-450)
                for bullet in bullets:
                    bullet.hideturtle()
                bullets.clear()
                target_pos = (0, 450)
                car_speed = 3
                steps = 30
                diff_x = (target_pos[0] - car.xcor()) / steps
                diff_y = (target_pos[1] - car.ycor()) / steps

                for _ in range(steps):
                    car.setx(car.xcor() + diff_x)
                    car.sety(car.ycor() + diff_y)
                    time.sleep(0.05)
                    win.update()
                    
                winner_declared = True
                winner = win.textinput("Mission Passed", "Next Level (yes/no)")
                if winner and winner.lower() == "yes":
                    win.bye()
                    os.system('Level-3.py')
                else:
                    win.bye()
                        
                for enemy, speed in enemy_list:
                    enemy.goto(enemy.xcor(), -400)

            if not game_over:
                current_time = time.time()
                if current_time - last_bullet_fire_time >= bullet_firing_delay:
                    fire_bullet()
                    last_bullet_fire_time = current_time  # Update last_bullet_fire_time after firing a bullet

                for bullet in bullets:
                    bullet.showturtle()
                    bullet.forward(bullet_speed)
                    if bullet.distance(car) < 20:
                        car.shape('explode.gif')
                        game_over = True
                        break

        else:
            if not winner_declared:
                for bullet in bullets:
                    bullet.hideturtle()
                helicopter.hideturtle()

    win.update()
    if not game_over:
        win.ontimer(game_loop, 16)
    else:
        car.shape('explode.gif')
        time.sleep(2)
        retry = win.textinput("Game Over", "Do you want to retry? (yes/no)")
        if retry and retry.lower() == "yes":
            reset_game()
            game_loop()
        else:
            win.bye()

start_time = time.time()

win.listen()
win.onkeypress(move_left, "a")
win.onkeypress(move_right, "d")
win.onkey(enter_car, "e")

game_loop()
win.mainloop()
