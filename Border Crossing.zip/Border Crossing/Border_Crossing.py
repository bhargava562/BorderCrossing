import turtle
import time
import os

win = turtle.Screen()
win.setup(1400,800)
win.title('Border Crossing')# title of the game
win.bgcolor('black')

instruction = turtle.Turtle()# title instruction
instruction.color('white')
instruction.ht()
instruction.up()
instruction.write("Tech Hub Presents...", align="center", font=("Algerian", 20, "normal"))
win.update()
time.sleep(3)
instruction.clear()
win.bgpic('company.gif')
win.update()
time.sleep(3)
win.bgpic('bordercrossing.gif')
win.update()
time.sleep(2)
instruction.goto(350,-300)
instruction.write("Press [e] \n to continue", font=("Algerian", 20, "normal"))

def start():
    win.bye()
    os.system('Level-1.py')

win.listen()
win.onkey(start,'e')

win.mainloop()
