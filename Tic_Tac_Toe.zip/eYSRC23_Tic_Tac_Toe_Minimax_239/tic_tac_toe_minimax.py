'''
*****************************************************************************************
*
*        		=================================================
*           	e-Yantra School Robotics Competition (eYSRC 2023)
*        		=================================================
*
*  This script is to be used to implement Mini Assignment titled- 'Tic Tac Toe: Player vs Player'.
*  
*  This software is made available on an "AS IS WHERE IS BASIS".
*  Licensee/end user indemnifies and will keep e-Yantra indemnified from
*  any and all claim(s) that emanate from the use of the Software or
*  breach of the terms of this agreement.
*  
*  e-Yantra - A MOE project under National Mission on Education using ICT (NMEICT)
*
*****************************************************************************************
'''

# Team ID:          
# 					[ 239 ]
# Author List:      
# 					[ Bhargava, Bommidevi]
# Filename:         tic_tac_toe.py
# Functions:        
#                   [ draw_xo, check_game_status, minimax, click, change_player]
# Global variables: 
# 					[ player ]

####################### IMPORT MODULES #######################
## You are not allowed to make any changes in this section. ##
## You have to implement this assignment with the available ##
## modules for this task.								    ##
##############################################################
import turtle
import copy   # https://www.geeksforgeeks.org/copy-python-deep-copy-shallow-copy/
import random
import math
##############################################################

# setting the window
win = turtle.Screen()
win.title("Tic Tac Toe")
win.bgcolor("black")

# setting the board
board = turtle.Turtle()
board.speed(0)
board.up()
board.sety(290)
board.color('Cyan')
board.down()
board.write('Tic Tac Toe', align='center', font=('Courier',14,'normal'))
board.up()
board.color('Deep Pink')
board.sety(260)
board.down()
board.write('click (X/O) in keyboard to select and start the game', align='center', font=('Courier',14,'normal'))
board.up()
board.color('orange')
board.sety(-270)
board.down()
board.write('You need to select the player to start', align='center', font=('Courier',10,'normal'))
board.up()
board.color('grey')
board.sety(-290)
board.down()
board.write('If not the X and O will not Print untill you select the player', align='center', font=('Courier',10,'normal'))

board.color('white')

# drawing 2 lines between
for i in range(2):
    board.penup()
    board.goto((i+1)*100-150, -150)
    board.pendown()
    board.goto((i+1)*100-150, 150)
    board.left(90)

for i in range(2):
    board.penup()
    board.goto(-150, (i+1)*100-150)
    board.pendown()
    board.goto(150, (i+1)*100-150)

board.hideturtle()

# creating a winner turtle
winner = turtle.Turtle()
winner.color('Yellow')
winner.speed(0)
winner.up()
winner.sety(-240)
winner.ht()

# setting game
game = [[" " for _ in range(3)] for _ in range(3)]

# setting up the player
player = None
player_turtle = turtle.Turtle()
player_turtle.color('white')
player_turtle.speed(0)
player_turtle.up()
player_turtle.goto(-200, 200)
player_turtle.ht()

# drawing the X and O at the grid
def draw_xo(row, col, player):
    x = col * 100 - 150
    y = -row * 100 + 150
    xo_turtle = turtle.Turtle()
    xo_turtle.color('white')
    xo_turtle.pensize(2)
    xo_turtle.hideturtle()
    xo_turtle.speed(0) 
    xo_turtle.penup()

    # for X
    if player == "X":              
        xo_turtle.color('green')
        xo_turtle.width(3)
        xo_turtle.goto(x + 20, y - 20)
        xo_turtle.pendown()
        xo_turtle.goto(x + 80, y - 80)
        xo_turtle.penup()
        xo_turtle.goto(x + 20, y - 80)
        xo_turtle.pendown()
        xo_turtle.goto(x + 80, y - 20)

    # for O    
    elif player == "O":                       
        xo_turtle.color('red')
        xo_turtle.width(3)
        xo_turtle.goto(x + 50, y - 80)
        xo_turtle.pendown()
        xo_turtle.circle(30)

# cheking the game status
def check_game_status():
    for i in range(3):
        if game[i][0] == game[i][1] == game[i][2] != " ":
            return game[i][0]
        
    for i in range(3):
        if game[0][i] == game[1][i] == game[2][i] != " ":
            return game[0][i]
        
    if game[0][0] == game[1][1] == game[2][2] != " ":
        return game[0][0]
    
    if game[0][2] == game[1][1] == game[2][0] != " ":
        return game[0][2]
    
    if " " not in [game[i][j] for i in range(3) for j in range(3)]:
        return "Draw"    
    return False

# creating the computer movement using minimax algorithm
def minimax(game, depth, maximizingPlayer):
    result = check_game_status()
    if result == "X":
        return {"score": 10 - depth}
    elif result == "O":
        return {"score": depth - 10}
    elif result == "Draw":
        return {"score": 0}

    # setting the X value
    if maximizingPlayer:
        bestScore = -math.inf
        move = {}
        for i in range(3):
            for j in range(3):
                if game[i][j] == " ":
                    game[i][j] = "X"
                    score = minimax(game, depth + 1, False)["score"]
                    game[i][j] = " "
                    if score > bestScore:
                        bestScore = score
                        move = {"score": bestScore, "row": i, "col": j}
        return move
    
    # setting the O value
    else:
        bestScore = math.inf
        move = {}
        for i in range(3):
            for j in range(3):
                if game[i][j] == " ":
                    game[i][j] = "O"
                    score = minimax(game, depth + 1, True)["score"]
                    game[i][j] = " "
                    if score < bestScore:
                        bestScore = score
                        move = {"score": bestScore, "row": i, "col": j}
        return move
    
# assigning screen click
def click(x, y):
    global player           # selecting the Player X or O
    if player is None:
        return
    
    col = math.floor((x + 150) / 100)
    row = math.floor((-y + 150) / 100)
    
    if game[row][col] == " " and -150 <= x <= 150 and -150 <= y <= 150: # assiging that the X and O must not draw outside the grid
        draw_xo(row, col, player)
        game[row][col] = player
        
        if check_game_status() == player:  # giving a winner      
            winner.write(f"{player} wins!",align='center',font=('Comic Sans MS',20,'normal'))
            
        elif check_game_status() == "Draw": # giving a draw
            winner.write("Draw!",align='center',font=('Comic Sans MS',20,'normal'))
            
        else:
            if player == "X":                      # cross assigning such that if Player is X computer is O or if player is O computer is X
                move = minimax(game, 0, False)
                draw_xo(move["row"], move["col"], "O")
                game[move["row"]][move["col"]] = "O"
                
            else:                          
                move = minimax(game, 0, True)
                draw_xo(move["row"], move["col"], "X")
                game[move["row"]][move["col"]] = "X"
                
            if check_game_status() != False:    # checking the status for the selected player
                winner.write(f"{check_game_status()} wins!",align='center',font=('Comic Sans MS',20,'normal'))
                
            elif check_game_status() == "Draw":
                winner.write("Draw!",align='center',font=('Comic Sans MS',20,'normal'))

# selecting player using keyboard controls
def change_player(x):
    global player
    if check_game_status() != False or player is not None:
        return
    player = x
    player_turtle.clear()
    player_turtle.up()
    player_turtle.goto(-200,200)
    player_turtle.down()
    player_turtle.color('lime')
    player_turtle.write(f"You selected:{player}", align='left', font=('Courier',17,'normal'))

win.onclick(click) # playing by click

win.onkey(lambda: change_player("X"), "x") # selecting player X by x key
win.onkey(lambda: change_player("O"), "o") # selecting player O by o key
win.listen()

# starting the game
turtle.mainloop()
